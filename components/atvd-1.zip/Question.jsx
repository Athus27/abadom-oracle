import React from 'react'

// Athus Silva Souza 22.2.8079

export const Question = () => {
  return (
    <table>
        <tr>
            <td>
            </td>
        </tr>
    </table>
  )
}
